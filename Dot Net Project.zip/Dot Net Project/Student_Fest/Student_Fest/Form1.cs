using Microsoft.VisualBasic.Devices;
using System;
using System.Data.SqlClient;
namespace Student_Fest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Load();
        }


        SqlConnection con = new SqlConnection("Data Source=DESKTOP-5GLFCNE; Initial Catalog=ABCD_School; User Id=Admin1; Password=admin123");
        SqlCommand cmd;
        SqlDataReader read;
        string id;
        bool mode = true;
        string sql;


        public void Load()
        {
            try
            {
                sql = "select * from Students";
                cmd = new SqlCommand(sql, con);
                con.Open();
                read = cmd.ExecuteReader();
                dataGridView1.Rows.Clear();

                while (read.Read())
                {
                    dataGridView1.Rows.Add(read[0], read[1], read[2], read[3], read[4]);
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }





        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string classes = txtClass.Text;
            string section = txtSection.Text;
            string roll = txtRoll.Text;

            if( mode == true )
            {
                sql = "insert into Students(stname,class,section,roll) values(@stname,@class,@section,@roll)";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@stname", txtName.Text);
                cmd.Parameters.AddWithValue("@class", txtClass.Text);
                cmd.Parameters.AddWithValue("@section", txtSection.Text);
                cmd.Parameters.AddWithValue("@roll", txtRoll.Text);
                MessageBox.Show("Record Added");
                cmd.ExecuteNonQuery();

                txtName.Clear();
                txtClass.Clear();
                txtSection.Clear();
                txtRoll.Clear();
                txtName.Focus();
            }
            else
            {

            }
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Load();
        }
    }
}