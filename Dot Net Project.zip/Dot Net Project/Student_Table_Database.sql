/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [ID]
      ,[stname]
      ,[class]
      ,[section]
      ,[roll]
  FROM [ABCD_School].[dbo].[Students]